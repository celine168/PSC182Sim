package groups;

public enum Groups {
 FISSION_FUSION,FISSION_MIGRATION, FISSION_EXTINCTION
}
